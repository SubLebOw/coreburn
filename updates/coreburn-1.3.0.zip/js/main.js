// main.js
// The starting point of COREBURN. It:
//   1. sets up Three.js (renderer, scene, camera, lights)
//   2. creates the arena, Sarrow, the waves, power-ups, the HUD and the controls
//   3. runs the game loop ~60 times a second: update everything, then draw
//   4. handles SLOW-MO (everything but Sarrow runs slower) and the fade between arenas
import * as THREE from 'three';
import { Input } from './input.js';
import { isTouchDevice, setupTouchControls } from './touch.js';
import { createArena, arenaForWave } from './arena.js';
import { Player } from './player.js';
import { WaveManager, isBossWave } from './waves.js';
import { Projectiles } from './projectiles.js';
import { Effects } from './effects.js';
import { Hud } from './hud.js';
import { PowerUps } from './powerups.js';
import { sound } from './audio.js';
import { ads } from './ads.js';
import { checkForUpdates } from './updater.js';
import { GAME_VERSION } from './version.js';
import { shareScore, copyScore } from './share.js';
import { IS_NATIVE } from './native.js';
import { Combo } from './combo.js';

const IS_TOUCH = isTouchDevice();
if (IS_TOUCH) document.body.classList.add('touch'); // shows the touch controls (see style.css)

// ---------- Renderer (draws the 3D scene onto a <canvas>) ----------
const renderer = new THREE.WebGLRenderer({ antialias: !IS_TOUCH, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2)); // cap at 2x so phones stay smooth
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = IS_TOUCH ? THREE.PCFShadowMap : THREE.PCFSoftShadowMap;
document.getElementById('game').appendChild(renderer.domElement);

// ---------- Scene (the arena sets the sky colour, fog and light colours) ----------
const scene = new THREE.Scene();

// ---------- Camera: isometric-style, looking down at about 45 degrees ----------
const camera = new THREE.PerspectiveCamera(32, 1, 0.5, 200); // low field-of-view = flatter, more 'isometric' look
const CAMERA_DIR = new THREE.Vector3(1, 1.35, 1).normalize(); // direction from the hero to the camera
let cameraDistance = 28;
const cameraTarget = new THREE.Vector3();
let shakeAmount = 0;

// ---------- Lights ----------
const hemi = new THREE.HemisphereLight(0xbfd8e0, 0x4a3426, 1.2); // sky colour + ground bounce
scene.add(hemi);
const sun = new THREE.DirectionalLight(0xffd2a0, 2.5);           // low sun with shadows
sun.castShadow = true;
sun.shadow.mapSize.set(IS_TOUCH ? 512 : 1024, IS_TOUCH ? 512 : 1024);
Object.assign(sun.shadow.camera, { left: -16, right: 16, top: 16, bottom: -16, near: 1, far: 60 });
sun.shadow.bias = -0.0015;
scene.add(sun, sun.target);

// ---------- Game objects ----------
const input = new Input(renderer.domElement);
setupTouchControls(input);
const hud = new Hud();
const effects = new Effects(scene);
const projectiles = new Projectiles(scene);
const env = { hemi, sun, baseHemi: 1.2 };
const arena = createArena(scene, env);

let state = 'title'; // 'title' | 'playing' | 'upgrade' (picker open, game paused) | 'gameover'
let kills = 0;
let score = 0;
let hitstopTimer = 0;
let deathTimer = 0;
let gameOverTime = 0;
let revivedThisRun = false; // the rewarded-ad revive can be used once per run
let reviveOffered = false;
let restarting = false;
let timeScale = 1;          // 0.35 during SLOW-MO (eases in and out)
let slowmoOn = false;
let transition = null;      // arena change in progress { t, index, loop, wave, swapped }
const TRANSITION_TIME = 0.9;
const combo = new Combo();  // hit streak -> score multiplier (see combo.js)
let upgradeTimer = 0;       // counts down after a boss dies, then the upgrade picker opens
const fadeEl = document.getElementById('fade');
const best = JSON.parse(localStorage.getItem('coreburn-best') || '{"score":0,"wave":0}');

// "world" is a shared object that the player and enemies use to reach each other
// and to trigger effects, without needing to know about main.js.
const world = {
  arena,
  env,
  effects,
  projectiles,
  player: null,
  enemies: null,
  powerups: null,
  shake(amount) { shakeAmount = Math.max(shakeAmount, amount); },
  sfx(name, option) { sound.play(name, option); },
  hitstop(seconds) { hitstopTimer = Math.max(hitstopTimer, seconds); }, // tiny freeze = punchy hits
  onPlayerHurt() { hud.flashDamage(); world.shake(0.2); combo.hurt(); },
  onComboHit() { combo.add(1); },
  onEnemyKilled(e) {
    kills++;
    sound.play('enemyDeath');
    combo.add(1);
    score += e.points * combo.mult;
    powerups.onKill(e);
    // Hive splitters burst into mites (unless they're crumbling because the boss died)
    if (e.type.splits && !e.crumble) {
      for (let i = 0; i < e.type.splits; i++) {
        const a = (i / e.type.splits) * Math.PI * 2;
        const m = enemies.spawnAt('mite', e.position.clone().add(new THREE.Vector3(Math.cos(a), 0, Math.sin(a))));
        if (m) m.stateTime = 0.4; // mites pop out quickly
      }
    }
  },
  // A new wave is about to start: every 10 waves we move to the next arena
  onWaveBegin(n) {
    const next = arenaForWave(n), cur = arena.current;
    if (next.index !== cur.index || next.loop !== cur.loop) {
      transition = { t: 0, index: next.index, loop: next.loop, wave: n, swapped: false };
      sound.play('arenaChange');
    }
  },
  onWaveStart(n) {
    if (transition) { sound.play('waveStart'); sound.setIntensity(1); return; } // the arena banner shows instead
    const msgs = { 1: 'The Grindchoir is coming', 2: 'Ripper hounds: they lunge!', 3: 'Slag spitters: dodge the bolts', 4: 'Bulwarks: only heavy hits stagger them', 6: 'Hive splitters burst into mites', 7: 'Elites (amber crowns) incoming' };
    hud.showBanner(`WAVE ${n}`, msgs[n] || '');
    sound.play('waveStart');
    sound.setIntensity(1);
  },
  onBossWave(n, def) {
    hud.showBanner(def.name, `Wave ${n} · ${def.subtitle}`);
    sound.play('bossWarning');
    sound.setIntensity(2); // boss music: faster and busier
  },
  onBossKilled(boss, parts = [boss]) {
    // Reward: big heal + score bonus, a power-up, and its minions crumble
    score += boss.points * combo.mult;
    kills += parts.length;
    world.player.heal(60);
    enemies.killAllAdds();
    world.shake(0.6);
    hud.showBanner('BOSS DOWN!', `+${boss.points * combo.mult} pts · +60 health`);
    sound.play('bossDefeated');
    sound.setIntensity(1);
    powerups.onKill(boss);
    upgradeTimer = 1.3; // let the BOSS DOWN moment land, then pause for the upgrade picker
  },
  // One of the Forge Twins fell; the other one gets angry
  onTwinDown(fallen, survivor) {
    hud.showBanner(`${fallen.def.partName} DOWN!`, survivor ? `${survivor.def.partName} is enraged!` : '');
    world.shake(0.5);
    sound.play('bossDefeated');
  },
  onTalonHit(e, damage) { powerups.onTalonHit(e, damage); },
  onPowerup(type, def) {
    sound.play('powerup');
    hud.showToast(def.name + '!', def.hint, '#' + def.color.toString(16).padStart(6, '0'));
  },
  onWaveCleared(n) {
    const bonus = 25 * n * combo.mult;
    score += bonus;
    if (!isBossWave(n)) {
      world.player.heal(25);
      hud.showBanner(`WAVE ${n} CLEARED`, `+${bonus} pts · +25 health`);
    }
  },
};
const player = new Player(scene, world);
const enemies = new WaveManager(scene, world);
const powerups = new PowerUps(scene, world);
world.player = player;
world.enemies = enemies;
world.powerups = powerups;

// SLOW-MO look and sound on/off
function setSlowmo(on) {
  if (slowmoOn === on) return;
  slowmoOn = on;
  document.body.classList.toggle('slowmo', on);
  sound.setSlowmo(on);
  if (state === 'playing') sound.play(on ? 'slowmoIn' : 'slowmoOut');
}

// Upgrade picker: pause, show 3 cards, apply the pick (weapon tier +1 and the card's perk)
function openUpgradePicker() {
  state = 'upgrade';
  const loadout = player.loadout;
  hud.showPicker(loadout.roll(3), loadout, (id) => {
    loadout.apply(id);
    player.applyLoadout();
    if (id === 'patch') player.heal(player.maxHp * 0.35);
    const def = loadout.def(id);
    hud.showToast(`TIER ${loadout.tier} TALONS`, `${def.name}${id === 'patch' ? '' : ' Lv ' + loadout.level(id)}`, '#' + def.color.toString(16).padStart(6, '0'));
    world.effects.spawnRing(player.position, player.tierColor, 3, 0.5);
    sound.play('powerup');
    state = 'playing';
  });
}

// Arena change: fade to black, swap the arena while it's dark, fade back in
function updateTransition(dt) {
  transition.t += dt;
  const half = TRANSITION_TIME / 2;
  if (!transition.swapped && transition.t >= half) {
    transition.swapped = true;
    arena.setTheme(transition.index, transition.loop);
    player.position.set(0, 0, 0); // the middle of every arena is clear
    player.slide.set(0, 0, 0);
    projectiles.reset();
    effects.reset();
    powerups.clearFloor();
    updateCamera(0, true);
    const a = arena.current;
    hud.showBanner(a.name, a.loop > 0 ? `Wave ${transition.wave} · Loop ${a.loop + 1}: everything hits harder` : `Wave ${transition.wave} · ${a.sub}`);
  }
  const t = transition.t;
  fadeEl.style.opacity = t < half ? t / half : Math.max(0, 1 - (t - half) / half);
  if (t >= TRANSITION_TIME) { transition = null; fadeEl.style.opacity = 0; }
}

// ---------- Starting / ending a run ----------
function startGame() {
  kills = 0;
  score = 0;
  combo.reset();
  deathTimer = 0;
  effects.reset();
  projectiles.reset();
  enemies.reset();
  player.reset();
  powerups.reset();
  hud.hidePicker();
  upgradeTimer = 0;
  transition = null;
  fadeEl.style.opacity = 0;
  timeScale = 1;
  setSlowmo(false);
  const cur = arena.current;
  if (cur.index !== 0 || cur.loop !== 0) arena.setTheme(0, 0); // back to the Slag Yard
  hud.hideOverlay();
  state = 'playing';
  revivedThisRun = false;
  enemies.startWave(1);
}

let lastRun = { wave: 1, score: 0, killer: null, place: null, tier: 0 }; // what the share buttons talk about

function gameOver() {
  state = 'gameover';
  gameOverTime = performance.now();
  const newBest = score > best.score;
  if (newBest) {
    best.score = score;
    best.wave = enemies.wave;
    localStorage.setItem('coreburn-best', JSON.stringify(best));
  }
  const killer = player.killedBy ? player.killedBy.killerName : null; // e.g. "the Furnace Deacon"
  lastRun = { wave: enemies.wave, score, killer, place: arena.current.place, tier: player.loadout.tier, combo: combo.best };
  upgradeTimer = 0;
  powerups.reset();
  setSlowmo(false);
  timeScale = 1;
  hud.showGameOver(score, enemies.wave, kills, best, newBest, killer, lastRun.place, player.loadout, combo.best);
  copyBtn.textContent = 'COPY';
  sound.play('gameOver');
  sound.setIntensity(0);
  ads.onGameOver();
  // Offer the optional rewarded-ad revive (Android app only, once per run)
  reviveOffered = !revivedThisRun && ads.canRevive;
  reviveBtn.classList.toggle('hidden', !reviveOffered);
  document.getElementById('restart-hint').classList.toggle('hidden', reviveOffered);
}

// Restart: any key, click or tap on the game over screen
// (with a short delay so a button you were mashing doesn't skip it immediately).
// Every few deaths an interstitial ad may show first (Android app only, see ads.js).
async function tryRestart(e) {
  if (state !== 'gameover' || restarting || performance.now() - gameOverTime < 600) return;
  if (e && e.code === 'KeyM') return;                 // M is the mute key
  if (e && e.target && e.target.closest && e.target.closest('.share-row')) return; // share/copy buttons
  if (reviveOffered && e && e.type !== 'click') return; // with a revive on offer, use the buttons
  restarting = true;
  try { await ads.maybeShowInterstitial(); } finally { restarting = false; }
  startGame();
}

// Rewarded ad -> come back with half health, once per run
const reviveBtn = document.getElementById('revive-btn');
reviveBtn.addEventListener('pointerdown', (e) => e.stopPropagation());
reviveBtn.addEventListener('click', async (e) => {
  e.stopPropagation();
  if (state !== 'gameover' || restarting) return;
  restarting = true;
  const rewarded = await ads.showRewarded();
  restarting = false;
  if (!rewarded) return;
  revivedThisRun = true;
  reviveOffered = false;
  reviveBtn.classList.add('hidden');
  // push nearby enemies away so the player gets a fair restart
  for (const en of enemies.list) {
    if (en.dead || en.isBoss) continue;
    const away = en.position.clone().sub(player.position).setY(0);
    if (away.length() < 8) { en.knockback.add(away.normalize().multiplyScalar(14)); en.stun = 1; }
  }
  projectiles.reset();
  player.revive();
  deathTimer = 0;
  hud.hideOverlay();
  state = 'playing';
  sound.play('revive');
  sound.setIntensity(enemies.boss && !enemies.boss.dead ? 2 : 1);
});

// Share my score / copy it (game over screen). These must not count as "tap to restart".
const shareBtn = document.getElementById('share-btn');
const copyBtn = document.getElementById('copy-btn');
for (const b of [shareBtn, copyBtn]) b.addEventListener('pointerdown', (e) => e.stopPropagation());
shareBtn.addEventListener('click', (e) => {
  e.stopPropagation();
  shareBtn.blur();
  shareScore(lastRun);
});
copyBtn.addEventListener('click', async (e) => {
  e.stopPropagation();
  copyBtn.blur();
  const ok = await copyScore(lastRun);
  copyBtn.textContent = ok ? 'COPIED!' : 'COPY FAILED';
  setTimeout(() => { copyBtn.textContent = 'COPY'; }, 2000);
});

window.addEventListener('keydown', tryRestart);
document.getElementById('overlay').addEventListener('pointerdown', tryRestart);
document.getElementById('start-btn').addEventListener('click', startGame);
document.getElementById('restart-btn').addEventListener('click', tryRestart);
hud.showTitle(best);
document.getElementById('version-text').textContent = `v${GAME_VERSION}`;

// ---------- Sound ----------
// Browsers only allow audio after a tap/click/key press, so start it on the first one.
const unlockAudio = () => sound.unlock();
for (const ev of ['pointerdown', 'keydown', 'touchend']) window.addEventListener(ev, unlockAudio, { capture: true });
const muteBtn = document.getElementById('mute-btn');
const showMute = () => muteBtn.classList.toggle('muted', sound.muted);
muteBtn.addEventListener('pointerdown', (e) => e.stopPropagation());
muteBtn.addEventListener('click', (e) => { e.stopPropagation(); sound.unlock(); sound.toggleMute(); showMute(); });
window.addEventListener('keydown', (e) => { if (e.code === 'KeyM') { sound.toggleMute(); showMute(); } });
showMute();

// ---------- Android-only extras (do nothing on the website) ----------
checkForUpdates();
ads.init().then(() => {
  const btn = document.getElementById('privacy-options-btn');
  if (ads.privacyOptionsRequired) {
    btn.classList.remove('hidden');
    btn.addEventListener('click', () => ads.showPrivacyOptions());
  }
});

// ---------- Resizing (also handles phones rotating between portrait and landscape) ----------
function onResize() {
  const w = window.innerWidth, h = window.innerHeight;
  renderer.setSize(w, h);
  camera.aspect = w / h;
  // Pull the camera back on narrow (portrait) screens so you can still see
  // about 9 metres to the left and right of the hero.
  const halfV = THREE.MathUtils.degToRad(camera.fov / 2);
  const halfH = Math.atan(Math.tan(halfV) * camera.aspect);
  cameraDistance = THREE.MathUtils.clamp(9 / Math.tan(halfH), 28, 42);
  camera.updateProjectionMatrix();
}
window.addEventListener('resize', onResize);
window.addEventListener('orientationchange', () => setTimeout(onResize, 200));
onResize();

// ---------- Camera follow ----------
function updateCamera(dt, snap = false) {
  // smoothly follow the hero
  const follow = snap ? 1 : 1 - Math.exp(-6 * dt);
  cameraTarget.lerp(player.position, follow);
  camera.position.copy(cameraTarget).addScaledVector(CAMERA_DIR, cameraDistance);
  // screen shake
  if (shakeAmount > 0) {
    camera.position.x += (Math.random() - 0.5) * shakeAmount;
    camera.position.y += (Math.random() - 0.5) * shakeAmount;
    camera.position.z += (Math.random() - 0.5) * shakeAmount;
    shakeAmount = Math.max(0, shakeAmount - dt * 1.5);
  }
  camera.lookAt(cameraTarget.x, cameraTarget.y + 0.8, cameraTarget.z);
  // keep the shadow-casting light centred on the action
  sun.position.set(cameraTarget.x + 10, 18, cameraTarget.z + 3);
  sun.target.position.copy(cameraTarget);
}

// ---------- The game loop ----------
const clock = new THREE.Clock();
updateCamera(0, true);

function frame() {
  requestAnimationFrame(frame);
  let dt = Math.min(clock.getDelta(), 1 / 20); // avoid huge jumps if the tab was in the background

  // hitstop: freeze the action for a split second on big hits
  if (hitstopTimer > 0) {
    hitstopTimer -= dt;
    dt *= 0.05;
  }

  // SLOW-MO: ease the world's speed towards 35% (Sarrow always uses the real dt)
  timeScale += (powerups.timeScale - timeScale) * (1 - Math.exp(-10 * dt));
  if (Math.abs(timeScale - powerups.timeScale) < 0.01) timeScale = powerups.timeScale;
  const worldDt = dt * timeScale;
  if (state === 'playing') setSlowmo(powerups.has('slowmo'));

  if (state === 'playing') {
    if (transition) {
      updateTransition(dt); // everything waits while the screen fades
    } else {
      player.update(dt, input);
      enemies.update(worldDt);
      projectiles.update(worldDt, player, arena, effects);
      arena.update(worldDt, player, world, true);
      powerups.update(dt);
      combo.update(worldDt);
      if (upgradeTimer > 0) {
        upgradeTimer -= dt;
        if (upgradeTimer <= 0 && !player.dead) openUpgradePicker();
      }
    }
    if (player.dead) {
      deathTimer += dt;
      if (deathTimer > 1.6) gameOver();
    }
  } else if (state === 'upgrade') {
    // paused while the player picks an upgrade (nothing moves)
  } else {
    // title screen: Enter or J also starts a run
    if (state === 'title' && (input.wasPressed('start') || input.wasPressed('attack'))) startGame();
    if (state === 'gameover') { enemies.update(dt); projectiles.update(dt, player, arena, effects); } // let things settle
    arena.update(dt, player, world, false);
  }

  if (state !== 'upgrade') effects.update(worldDt);
  updateCamera(dt);
  hud.updateCombo(combo, state === 'playing');
  hud.update(player, Math.max(1, enemies.wave), kills, score, state === 'playing' ? enemies.bossBar : null, powerups.hudList);
  input.endFrame();
  renderer.render(scene, camera);
}
frame();

// Testing helpers for the browser console live in js/dev.local.js, which is NOT part of the
// game: it's git-ignored and left out of the build, so it never reaches the website or the
// Android app. It only loads when you run the game on your own computer (http://localhost...).
const LOCAL_DEV = !IS_NATIVE && ['localhost', '127.0.0.1'].includes(location.hostname);
if (LOCAL_DEV) {
  import('./dev.local.js')
    .then((m) => m.install({ player, enemies, world, arena, powerups, projectiles, effects, hud, sound, ads, startGame, snapCamera: () => updateCamera(0, true), getScore: () => score, combo }))
    .catch(() => {}); // no dev file = no helpers, that's fine
}
