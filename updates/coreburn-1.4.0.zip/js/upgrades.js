// upgrades.js
// After every 2nd wave (2, 4, 6, ...) you CHOOSE one of 3 upgrade cards. Same rate in solo and co-op.
// Every pick does two things:
//
//  1. WEAPON TIER +1 (the even scaling). The hero's base damage multiplier is
//         weaponMult(tier) = 1 + 0.28 * tier
//     Why 0.28? Enemy health grows by 0.14 per wave (waves.js: hpMult = 1 + 0.14(n-1)) and you
//     pick every 2 waves, so 2 x 0.14 = 0.28. After wave 2t you have tier t, and the next wave
//     (2t+1) has hpMult = 1 + 0.28t: exactly your weaponMult. So hits-to-kill at the start of every
//     2-wave stretch is the SAME as at wave 1, whatever cards you picked or hero you play.
//
//  2. The card itself: a small, capped perk on top (the "extra edge"). Perk steps are small and
//     caps are high, so the perks grow slowly over ~50 picks by wave 100. All damage perks together
//     top out at about 2x single-target damage, while enemy damage keeps growing every wave (+7%),
//     so late waves stay dangerous.
//
// Once a card is maxed it stops appearing; if fewer than 3 cards are left, REACTOR PATCH fills in.
// Every card works for all three heroes (percent-based, on top of each hero's own numbers).
// This file has no Three.js in it, so tools (like the time-to-kill simulator) can import it too.

export const WEAPON_TIER_STEP = 0.28; // = 0.14 enemy health per wave x 2 waves per pick
export const PICK_EVERY = 2;          // waves between upgrade picks
export const isPickWave = (n) => n > 0 && n % PICK_EVERY === 0;

export function weaponMult(tier) { return 1 + WEAPON_TIER_STEP * tier; }

// Talon colour by tier: teal -> cyan -> white-gold -> violet -> crimson (every 6 tiers, blended)
const TIER_COLOURS = [0x7ffff2, 0x3fc8ff, 0xffe6a0, 0xb070ff, 0xff3048];
export function tierColor(tier, base = TIER_COLOURS[0]) {
  const k = Math.min(TIER_COLOURS.length - 1, tier / 6);
  const i = Math.floor(k), f = k - i;
  const col = (j) => (j === 0 ? base : TIER_COLOURS[j]);
  const a = col(i), b = col(Math.min(TIER_COLOURS.length - 1, i + 1));
  const ch = (s) => Math.round(((a >> s) & 255) * (1 - f) + ((b >> s) & 255) * f);
  return (ch(16) << 16) | (ch(8) << 8) | ch(0);
}

// group: talons / overdrive / blink / core. desc(level) = what the NEXT level gives.
export const UPGRADES = {
  // ---- talons ----
  edge:     { name: 'Talon Edge', group: 'talons', icon: '✦', color: 0xff8a3a, max: 10, desc: () => '+3.5% talon damage' },
  arc:      { name: 'Wide Arc', group: 'talons', icon: '◠', color: 0x7ffff2, max: 6, desc: () => '+6% slash reach, wider swing' },
  shock:    { name: 'Shockwave Finisher', group: 'talons', icon: '◎', color: 0xffd040, max: 5, desc: (l) => l === 0 ? 'Combo finisher sends out a shockwave' : 'Bigger, stronger finisher shockwave' },
  crit:     { name: 'Crit Spark', group: 'talons', icon: '✸', color: 0xfff27a, max: 8, desc: () => '+3.5% chance for 1.8x critical hits' },
  twin:     { name: 'Twin Strike', group: 'talons', icon: '⫽', color: 0x9ab8ff, max: 6, desc: () => '+4% chance to hit twice' },
  storm:    { name: 'Storm Talons', group: 'talons', icon: 'ϟ', color: 0x8ab4ff, max: 6, desc: () => '+7.5% chance hits chain lightning to 2 foes' },
  leech:    { name: 'Core Leech', group: 'talons', icon: '♥', color: 0x6aff7a, max: 6, desc: () => 'Heal +0.25 per talon hit (max 6/s)' },
  // ---- overdrive (spin / slam) ----
  odTime:   { name: 'Long Overdrive', group: 'overdrive', icon: '⟲', color: 0xff8a3a, max: 6, desc: () => '+0.2s overdrive duration' },
  odRadius: { name: 'Overdrive Reach', group: 'overdrive', icon: '⭘', color: 0xffb060, max: 6, desc: () => '+6% overdrive radius' },
  odDamage: { name: 'Overdrive Fury', group: 'overdrive', icon: '✺', color: 0xff5a2a, max: 6, desc: () => '+12.5% overdrive damage' },
  odLeech:  { name: 'Overdrive Siphon', group: 'overdrive', icon: '❥', color: 0xff6aa0, max: 6, desc: () => 'Heal +0.5 per overdrive hit (max 10/s)' },
  odCool:   { name: 'Overdrive Coolant', group: 'overdrive', icon: '❄', color: 0x9ae4ff, max: 6, desc: () => '-5% overdrive cooldown' },
  // ---- blink (dash / charge) ----
  bkDamage: { name: 'Blink Edge', group: 'blink', icon: '➹', color: 0x3ff6e0, max: 6, desc: () => '+25% blink damage' },
  bkRange:  { name: 'Long Blink', group: 'blink', icon: '⇢', color: 0x6ad8ff, max: 6, desc: () => '+7.5% blink distance' },
  bkCharge: { name: 'Extra Blink', group: 'blink', icon: '⇉', color: 0xc8a0ff, max: 1, desc: () => '+1 blink charge' },
  bkCool:   { name: 'Quick Blink', group: 'blink', icon: '⟳', color: 0x7affc8, max: 6, desc: () => '-6% blink cooldown' },
  bkTrail:  { name: 'Blink Trail', group: 'blink', icon: '≋', color: 0x3fd0ff, max: 5, desc: (l) => l === 0 ? 'Blink leaves a burning trail' : 'Trail burns hotter' },
  // ---- core (the hero) ----
  speed:    { name: 'Swift Step', group: 'core', icon: '»', color: 0xd0ff6a, max: 6, desc: () => '+3% move speed' },
  maxHp:    { name: 'Reinforced Core', group: 'core', icon: '⬢', color: 0x6aff9a, max: 8, desc: () => '+7.5% max health' },
  regen:    { name: 'Core Recharge', group: 'core', icon: '✚', color: 0x3ff6a0, max: 6, desc: () => '+17.5% health regen' },
};
export const FALLBACK = { id: 'patch', name: 'Reactor Patch', group: 'core', icon: '⛨', color: 0xc8c8c8, max: Infinity, desc: () => '+3 max health and heal 35%' };
export const GROUP_LABELS = { talons: 'TALONS', overdrive: 'OVERDRIVE', blink: 'BLINK', core: 'CORE' };

export class Loadout {
  constructor() { this.reset(); }

  reset() {
    this.tier = 0;
    this.levels = {};
    this.patches = 0;
    this.version = 0; // bumps on every change (the HUD redraws when it changes)
    this.recompute();
  }

  level(id) { return id === 'patch' ? this.patches : (this.levels[id] || 0); }
  def(id) { return id === 'patch' ? FALLBACK : UPGRADES[id]; }

  // 3 different random cards that aren't maxed yet (Reactor Patch fills any gaps)
  roll(count = 3, rng = Math.random) {
    const open = Object.keys(UPGRADES).filter((id) => this.level(id) < UPGRADES[id].max);
    const hand = [];
    while (hand.length < count && open.length) hand.push(open.splice(Math.floor(rng() * open.length), 1)[0]);
    if (hand.length < count) hand.push('patch');
    return hand;
  }

  apply(id) {
    this.tier++;
    if (id === 'patch') this.patches++;
    else this.levels[id] = Math.min(UPGRADES[id].max, this.level(id) + 1);
    this.version++;
    this.recompute();
  }

  // Everything the player needs, as plain multipliers/numbers
  recompute() {
    const L = (id) => this.level(id);
    this.stats = {
      weapon: weaponMult(this.tier),
      dmg: weaponMult(this.tier) * (1 + 0.035 * L('edge')),
      range: 1 + 0.06 * L('arc'),
      arcLevel: L('arc'),
      shock: L('shock'),                          // radius 2.8 + 0.3L, 30% + 9%L of the finisher
      crit: 0.035 * L('crit'),
      twin: 0.04 * L('twin'),
      storm: 0.075 * L('storm'),
      leech: 0.25 * L('leech'),
      spinTime: 0.2 * L('odTime'),
      spinRadius: 1 + 0.06 * L('odRadius'),
      spinDmg: 1 + 0.125 * L('odDamage'),
      spinLeech: 0.5 * L('odLeech'),
      spinCd: 1 - 0.05 * L('odCool'),
      dashDmg: 1 + 0.25 * L('bkDamage'),
      dashTime: 1 + 0.075 * L('bkRange'),
      dashCharges: 1 + L('bkCharge'),
      dashCd: 1 - 0.06 * L('bkCool'),
      trail: L('bkTrail') * 0.6,                  // trail tick = (4 + 3 x this) x damage
      speed: 1 + 0.03 * L('speed'),
      maxHpPct: 0.075 * L('maxHp'),
      maxHpFlat: 3 * this.patches,
      regen: 1 + 0.175 * L('regen'),
    };
  }

  // Expected single-target damage multiplier from perks alone (for balancing / the simulator)
  get perkDamageMult() {
    const s = this.stats;
    return (s.dmg / s.weapon) * (1 + 0.8 * s.crit) * (1 + s.twin);
  }

  // e.g. [{ id, name, icon, color, level }]
  get picked() {
    const list = Object.keys(UPGRADES).filter((id) => this.level(id) > 0).map((id) => ({ id, ...UPGRADES[id], level: this.level(id) }));
    if (this.patches) list.push({ ...FALLBACK, level: this.patches });
    return list;
  }
}
